export const BUILD_METADATA = {
  "builtAt": "2026-04-22T16:19:33.225Z",
  "commitSha": null,
  "release": "local-dev"
} as const;
